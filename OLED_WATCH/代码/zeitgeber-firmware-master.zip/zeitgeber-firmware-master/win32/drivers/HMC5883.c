/*
 * File:   win32/drivers/HMC5883.c
 * Author: Jared
 *
 * Created on 5 July 2013, 4:07 PM
 *
 * --WIN32 SPECIFIC DRIVER--
 * Returns sample magnetometer data
 */

////////// Includes ////////////////////////////////////////////////////////////

#include <system.h>
#include "drivers/HMC5883.h"
//#include "peripherals/i2c.h"

////////// Methods /////////////////////////////////////////////////////////////

bool mag_init() {
    return false;
}