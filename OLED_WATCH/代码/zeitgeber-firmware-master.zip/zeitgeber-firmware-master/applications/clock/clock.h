/* 
 * File:   applications/clock/clock.h
 * Author: Jared
 *
 * Created on 14 February 2014, 1:39 PM
 */

#ifndef APP_CLOCK_H
#define	APP_CLOCK_H

extern application_t appclock;

#endif	/* APP_CLOCK_H */

