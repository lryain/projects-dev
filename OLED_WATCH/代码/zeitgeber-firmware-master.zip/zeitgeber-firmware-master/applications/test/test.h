/* 
 * File:   applications/main/appmain.h
 * Author: Jared
 *
 * Created on 5 July 2013, 12:48 PM
 */

#ifndef APP_MAIN_H
#define	APP_MAIN_H

extern application_t apptest;

#endif	/* APP_MAIN_H */

