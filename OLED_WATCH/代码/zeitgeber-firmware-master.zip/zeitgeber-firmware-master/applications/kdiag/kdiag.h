/* 
 * File:   applications/kdiag/kdiag.h
 * Author: Jared
 *
 * Created on 17 February 2104, 1:58 PM
 */

#ifndef APP_KDIAG_H
#define	APP_KDIAG_H

extern application_t appkdiag;

#endif	/* APP_KDIAG_H */

