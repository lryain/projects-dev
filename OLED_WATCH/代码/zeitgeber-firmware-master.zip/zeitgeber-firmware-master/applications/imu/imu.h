/* 
 * File:   applications/imu/imu.h
 * Author: Jared
 *
 * Created on 14 February 2014, 1:39 PM
 */

#ifndef APP_IMU_H
#define	APP_IMU_H

extern application_t appimu;

#endif	/* APP_IMU_H */

