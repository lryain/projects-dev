/*
 * File:   usb.h
 * Author: Jared
 *
 * Created on 5 July 2013, 4:07 PM
 */

#ifndef USB_H
#define	USB_H

//extern bool InitializeUsb();

#endif	/* USB_H */