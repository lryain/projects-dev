/*
 * File:   vector.c
 * Author: Jared
 *
 * Created on 5 July 2013, 4:07 PM
 */

////////// Includes ////////////////////////////////////////////////////////////

#include "system.h"
#include <math.h>
#include "vector.h"

////////// Methods /////////////////////////////////////////////////////////////

//TODO: Use fast integer math instead.
int16 vec3magnitude(vector3i_t* vec) {
    /*return sqrt(
        vec->x * vec->x +
        vec->y * vec->y +
        vec->z * vec->z
    );*/
    return 0;
}

