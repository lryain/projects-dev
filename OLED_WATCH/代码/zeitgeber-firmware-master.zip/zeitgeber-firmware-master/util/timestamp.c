/*
 * File:   api/timestamp.c
 * Author: Jared
 *
 * Created on 20 February 2014, 1:45 PM
 */

#include "system.h"
#include "timestamp.h"
#include "api/clock.h"

void timestamp2time(timestamp_t ts, rtc_time_t* time) {
    
}

void timestamp2date(timestamp_t ts, rtc_date_t* date) {

}