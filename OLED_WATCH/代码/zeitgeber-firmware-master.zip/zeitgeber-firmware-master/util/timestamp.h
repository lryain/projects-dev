/* 
 * File:   api/timestamp.h
 * Author: Jared
 *
 * Created on 20 February 2014, 1:45 PM
 */

#ifndef TIMESTAMP_H
#define	TIMESTAMP_H

//typedef uint16 timestamp_t;

#endif	/* TIMESTAMP_H */

