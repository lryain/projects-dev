/*
 * File:   pwm.h
 * Author: Jared
 *
 * Created on 5 July 2013, 4:07 PM
 */

#ifndef PWM_H
#define	PWM_H

extern void pwm_init();

#endif	/* PWM_H */