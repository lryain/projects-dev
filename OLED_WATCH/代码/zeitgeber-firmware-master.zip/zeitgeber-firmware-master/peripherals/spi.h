/*
 * File:   spi.h
 * Author: Jared
 *
 * Created on 5 July 2013, 4:07 PM
 */

#ifndef SPI_H
#define	SPI_H

extern void spi_init();

#endif	/* SPI_H */