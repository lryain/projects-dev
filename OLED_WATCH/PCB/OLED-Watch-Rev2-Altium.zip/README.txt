OLED Watch Rev2
Author: Jared Sanson
License: OSHW http://freedomdefined.org/OSHW
Website: http://jared.geek.nz/