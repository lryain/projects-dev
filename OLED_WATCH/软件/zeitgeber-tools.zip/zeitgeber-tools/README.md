# Zeitgeber-Tools

"Time Keeper"

This repository contains various tools written in C# for interfacing with my [open-source OLED Watch project](http://jared.geek.nz/2014/jul/oshw-oled-watch).

## Features ##

- USB HID interface
- Time sync
- Screenshot capture
- Debug message console
