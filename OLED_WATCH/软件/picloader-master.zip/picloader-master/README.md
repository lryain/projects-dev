PICLoader
=========

C# command line USB-HID bootloader program for Microchip's PIC devices

This is basically a port of the core functionality of Microchip's C++ HID bootloader GUI, 
but re-written to be object-oriented, and wrapped in a console interface.

Can be embedded in your custom C# application, 
or can be added to the post-build events in MPLABX for automatic programming.
